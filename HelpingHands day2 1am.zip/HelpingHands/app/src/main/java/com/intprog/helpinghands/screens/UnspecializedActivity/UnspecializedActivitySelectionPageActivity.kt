package com.intprog.helpinghands.screens.UnspecializedActivity

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import com.intprog.helpinghands.HomePageActivity
import com.intprog.helpinghands.R
import com.intprog.helpinghands.model.Post

class UnspecializedActivitySelectionPageActivity : AppCompatActivity() {

    private val posts = mutableListOf<Post>()
    private lateinit var listView: ListView
    private lateinit var adapter: PostAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_unspecialized_selection)

        listView = findViewById(R.id.unspecializedActivityListView)
        adapter = PostAdapter(this, R.layout.activity_unspecialized_selection_item, posts)
        listView.adapter = adapter

        val post = intent.getParcelableExtra<Post>("post")
        if (post != null) {
            addPost(post)
        }

        val homeImageButton = findViewById<ImageButton>(R.id.homeImageButton)
        homeImageButton.setOnClickListener {
            val intent = Intent(this, HomePageActivity::class.java)
            startActivity(intent)
        }
    }

    fun addPost(post: Post) {
        posts.add(post)
        adapter.notifyDataSetChanged()
    }

    override fun onResume() {
        super.onResume()
        adapter.notifyDataSetChanged()
    }

    private inner class PostAdapter(
        context: Context,
        resource: Int,
        objects: MutableList<Post>
    ) : ArrayAdapter<Post>(context, resource, objects) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            var itemView = convertView
            if (itemView == null) {
                val inflater = LayoutInflater.from(context)
                itemView = inflater.inflate(R.layout.activity_unspecialized_selection_item, parent, false)
            }

            val post = getItem(position)
            val titleTextView = itemView!!.findViewById<TextView>(R.id.ActivityTitleTextView)
            val imageView = itemView.findViewById<ImageButton>(R.id.activityImageView)
            val viewDetailsButton = itemView.findViewById<Button>(R.id.viewDetailsButton)

            titleTextView.text = post?.title
            imageView.setImageURI(Uri.parse(post?.imageUri))

            // Set click listener for view details button
            viewDetailsButton.setOnClickListener {
                // Handle click event here
            }

            return itemView
        }
    }
}
