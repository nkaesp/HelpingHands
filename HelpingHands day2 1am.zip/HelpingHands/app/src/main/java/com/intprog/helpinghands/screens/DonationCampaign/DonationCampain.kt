package com.intprog.helpinghands.screens.DonationCampaign

data class DonationCampaign(
    val title: String?,
    val imageResId: Int // Resource ID for the image
)
