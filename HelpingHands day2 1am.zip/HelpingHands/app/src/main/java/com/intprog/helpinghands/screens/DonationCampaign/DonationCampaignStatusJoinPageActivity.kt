package com.intprog.helpinghands.screens.DonationCampaign

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.intprog.helpinghands.R

class DonationCampaignStatusJoinPageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donation_campaign_status_join_page)
    }
}